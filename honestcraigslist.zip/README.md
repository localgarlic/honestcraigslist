# Honest Craigslist
Chrome extension to translate Slumlordspeak into English.